#!/usr/bin/env python3
"""
Monthly Pylon KB authoring report.

Fetches all knowledge-base articles created in a given calendar month by a
fixed roster of engineers, then writes a self-contained Excel workbook with
a Summary sheet (per-engineer counts) and a Details sheet (one row per
article). Designed to be run on a schedule (launchd / cron).

Usage:
    python3 pylon_monthly_report.py                      # previous full month
    python3 pylon_monthly_report.py --month 2026-04      # explicit month
    python3 pylon_monthly_report.py --output ~/Reports
    python3 pylon_monthly_report.py --roster roster.json

Env vars (any one works):
    PYLON_API_KEY | PYLON_TOKEN | pylon_token

Requirements:
    pip3 install requests openpyxl

Roster file format (optional override for --roster):
    {"engineers": ["Full Name 1", "Full Name 2", ...]}
"""

from __future__ import annotations

import argparse
import calendar
import csv
import json
import os
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterable

import requests
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

API = "https://api.usepylon.com"

DEFAULT_ROSTER = [
    "Fariha Marzan",
    "Tassia Shibuya",
    "Tim Perry",
    "Dylan Bonar",
    "Robert Norrie",
    "Chinmay Koratkar",
    "Saurabh Lambe",
    "Tommy Lundy",
    "Bryan Nalty",
    "Feran Morgan",
]


# --------------------------------------------------------------------------- CLI

def previous_full_month(today: date | None = None) -> tuple[int, int]:
    today = today or date.today()
    y, m = today.year, today.month
    return (y - 1, 12) if m == 1 else (y, m - 1)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Generate monthly Pylon KB authoring report.")
    p.add_argument("--month", help="Target month as YYYY-MM. Default: previous full month.")
    p.add_argument("--output", default=".", help="Directory to write the .xlsx into. Default: current dir.")
    p.add_argument("--roster", help="Path to JSON file with 'engineers' list. Default: built-in roster.")
    p.add_argument(
        "--slack-channel",
        default=os.environ.get("SLACK_CHANNEL"),
        help="Slack channel ID or #channel-name to post the summary to. "
        "Can also be set via SLACK_CHANNEL env var. If omitted, Slack posting is skipped.",
    )
    p.add_argument(
        "--no-slack",
        action="store_true",
        help="Skip Slack posting even if SLACK_BOT_TOKEN/SLACK_CHANNEL are set.",
    )
    return p.parse_args()


def resolve_month(arg: str | None) -> tuple[int, int]:
    if not arg:
        return previous_full_month()
    try:
        y, m = arg.split("-")
        return int(y), int(m)
    except Exception:
        sys.exit(f"ERROR: --month must be YYYY-MM, got '{arg}'")


def load_roster(path: str | None) -> list[str]:
    if not path:
        return DEFAULT_ROSTER
    with open(path) as f:
        data = json.load(f)
    roster = data.get("engineers") if isinstance(data, dict) else data
    if not isinstance(roster, list) or not all(isinstance(x, str) for x in roster):
        sys.exit(f"ERROR: roster file {path} must contain an 'engineers' list of strings.")
    return roster


def month_bounds_utc(year: int, month: int) -> tuple[datetime, datetime]:
    last_day = calendar.monthrange(year, month)[1]
    start = datetime(year, month, 1, tzinfo=timezone.utc)
    end = datetime(year, month, last_day, 23, 59, 59, tzinfo=timezone.utc)
    # Exclusive upper bound: first of next month
    if month == 12:
        upper = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
    else:
        upper = datetime(year, month + 1, 1, tzinfo=timezone.utc)
    return start, upper


# --------------------------------------------------------------------------- HTTP

def get_token() -> str:
    for k in ("PYLON_API_KEY", "PYLON_TOKEN", "pylon_token"):
        v = os.environ.get(k)
        if v:
            return v
    sys.exit("ERROR: set PYLON_API_KEY (or PYLON_TOKEN / pylon_token) before running.")


def make_session(token: str) -> requests.Session:
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}", "Accept": "application/json"})
    return s


def get(session: requests.Session, path: str, params: dict | None = None) -> dict:
    url = f"{API}{path}"
    for attempt in range(5):
        r = session.get(url, params=params, timeout=30)
        if r.status_code == 429 or r.status_code >= 500:
            time.sleep(2 ** attempt)
            continue
        r.raise_for_status()
        return r.json()
    r.raise_for_status()
    return {}


def paginate(session: requests.Session, path: str, params: dict | None = None) -> Iterable[dict]:
    params = dict(params or {})
    while True:
        body = get(session, path, params=params)
        for item in body.get("data", []):
            yield item
        pg = body.get("pagination") or {}
        if not pg.get("has_next_page"):
            return
        params["cursor"] = pg.get("cursor")


# --------------------------------------------------------------------------- Pylon data

def build_user_map(session: requests.Session) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for u in paginate(session, "/users"):
        name = (u.get("name") or "").strip()
        if not name:
            first = (u.get("first_name") or "").strip()
            last = (u.get("last_name") or "").strip()
            name = f"{first} {last}".strip()
        if name and u.get("id"):
            mapping[name.lower()] = u["id"]
    return mapping


def fetch_articles(session: requests.Session) -> Iterable[dict]:
    for kb in paginate(session, "/knowledge-bases"):
        yield from paginate(session, f"/knowledge-bases/{kb['id']}/articles")


def filter_rows(
    articles: Iterable[dict],
    target_ids: dict[str, str],
    lower: datetime,
    upper: datetime,
) -> list[dict]:
    out: list[dict] = []
    for a in articles:
        uid = a.get("author_user_id") or ""
        if uid not in target_ids:
            continue
        ts = a.get("created_at") or ""
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            continue
        if not (lower <= dt < upper):
            continue
        out.append({
            "engineer": target_ids[uid],
            "title": a.get("title", ""),
            "status": "Published" if a.get("is_published") else "Draft",
            "created_date": dt.date().isoformat(),
            "article_id": a.get("id", ""),
            "url": a.get("url", ""),
        })
    return out


# --------------------------------------------------------------------------- Excel

HEADER_FILL = PatternFill("solid", start_color="1F4E78")
HEADER_FONT = Font(name="Arial", bold=True, color="FFFFFF", size=11)
BODY_FONT = Font(name="Arial", size=11)
BOLD = Font(name="Arial", bold=True)
TITLE_FONT = Font(name="Arial", bold=True, size=14)
SUBTITLE_FONT = Font(name="Arial", italic=True, size=10, color="595959")
CENTER = Alignment(horizontal="center", vertical="center")
LEFT = Alignment(horizontal="left", vertical="center")
THIN = Side(border_style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
TOTAL_FILL = PatternFill("solid", start_color="DCE6F1")

MONTH_NAMES = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


def write_workbook(
    out_path: Path,
    year: int,
    month: int,
    roster: list[str],
    rows: list[dict],
    missing_names: list[str],
) -> None:
    wb = Workbook()
    month_label = f"{MONTH_NAMES[month]} {year}"

    # ---- Summary ----
    ws = wb.active
    ws.title = "Summary"

    ws["A1"] = f"KB Articles Created by Engineer \u2014 {month_label}"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells("A1:E1")
    ws["A2"] = "Source: Pylon knowledge base. Status derived from is_published."
    ws["A2"].font = SUBTITLE_FONT
    ws.merge_cells("A2:E2")

    headers = ["Engineer", "# Articles", "# Draft", "# Published", "Notes"]
    for col, h in enumerate(headers, 1):
        c = ws.cell(row=4, column=col, value=h)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = CENTER
        c.border = BORDER

    for i, name in enumerate(roster, start=5):
        ws.cell(row=i, column=1, value=name).font = BODY_FONT
        ws.cell(row=i, column=2, value=f'=COUNTIF(Details!$A$2:$A$501, A{i})')
        ws.cell(row=i, column=3, value=f'=COUNTIFS(Details!$A$2:$A$501, A{i}, Details!$C$2:$C$501, "Draft")')
        ws.cell(row=i, column=4, value=f'=COUNTIFS(Details!$A$2:$A$501, A{i}, Details!$C$2:$C$501, "Published")')
        note = ""
        if name in missing_names:
            note = "Could not resolve Pylon user ID for this name."
        ws.cell(row=i, column=5, value=note)
        for col in range(1, 6):
            cell = ws.cell(row=i, column=col)
            cell.border = BORDER
            cell.font = BODY_FONT
            cell.alignment = LEFT if col in (1, 5) else CENTER

    total_row = 5 + len(roster)
    ws.cell(row=total_row, column=1, value="Total").font = BOLD
    ws.cell(row=total_row, column=2, value=f'=SUM(B5:B{total_row-1})').font = BOLD
    ws.cell(row=total_row, column=3, value=f'=SUM(C5:C{total_row-1})').font = BOLD
    ws.cell(row=total_row, column=4, value=f'=SUM(D5:D{total_row-1})').font = BOLD
    for col in range(1, 6):
        cell = ws.cell(row=total_row, column=col)
        cell.border = BORDER
        cell.fill = TOTAL_FILL
        if col > 1:
            cell.alignment = CENTER

    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 13
    ws.column_dimensions["C"].width = 11
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 44
    ws.row_dimensions[1].height = 22
    ws.freeze_panes = "A5"

    # ---- Details ----
    det = wb.create_sheet("Details")
    det_headers = ["Engineer", "Topic / Title", "Status", "Created Date", "Article ID", "URL"]
    for col, h in enumerate(det_headers, 1):
        c = det.cell(row=1, column=col, value=h)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = CENTER
        c.border = BORDER

    # Pre-format 500 rows
    for r in range(2, 502):
        for col in range(1, 7):
            cell = det.cell(row=r, column=col)
            cell.font = BODY_FONT
            cell.border = BORDER
            if col == 4:
                cell.number_format = "yyyy-mm-dd"
            cell.alignment = LEFT if col in (1, 2, 5, 6) else CENTER

    # Validations
    dv_status = DataValidation(type="list", formula1='"Draft,Published"', allow_blank=True)
    dv_status.add("C2:C501")
    det.add_data_validation(dv_status)
    dv_eng = DataValidation(
        type="list",
        formula1=f"=Summary!$A$5:$A${4+len(roster)}",
        allow_blank=True,
    )
    dv_eng.add("A2:A501")
    det.add_data_validation(dv_eng)

    # Populate rows
    for i, row in enumerate(rows, start=2):
        det.cell(row=i, column=1, value=row["engineer"])
        det.cell(row=i, column=2, value=row["title"])
        det.cell(row=i, column=3, value=row["status"])
        try:
            dt = date.fromisoformat(row["created_date"])
            det.cell(row=i, column=4, value=dt)
            det.cell(row=i, column=4).number_format = "yyyy-mm-dd"
        except ValueError:
            det.cell(row=i, column=4, value=row["created_date"])
        det.cell(row=i, column=5, value=row["article_id"])
        det.cell(row=i, column=6, value=row["url"])

    det.column_dimensions["A"].width = 22
    det.column_dimensions["B"].width = 48
    det.column_dimensions["C"].width = 12
    det.column_dimensions["D"].width = 14
    det.column_dimensions["E"].width = 36
    det.column_dimensions["F"].width = 48
    det.freeze_panes = "A2"

    # ---- Metadata sheet ----
    meta = wb.create_sheet("Run info")
    meta["A1"] = "Run metadata"
    meta["A1"].font = TITLE_FONT
    meta["A3"] = "Report month:"
    meta["B3"] = month_label
    meta["A4"] = "Generated at (UTC):"
    meta["B4"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    meta["A5"] = "Articles pulled:"
    meta["B5"] = len(rows)
    meta["A6"] = "Unresolved engineers:"
    meta["B6"] = ", ".join(missing_names) if missing_names else "(none)"
    meta["A8"] = "Field mapping"
    meta["A8"].font = BOLD
    pairs = [
        ("Engineer", "resolved from Pylon user.name (case-insensitive)"),
        ("Topic / Title", "article.title"),
        ("Status", "Published if article.is_published else Draft"),
        ("Created Date", "article.created_at (UTC, truncated to date)"),
        ("Article ID", "article.id"),
        ("URL", "article.url (empty if unpublished)"),
    ]
    for i, (k, v) in enumerate(pairs, start=9):
        meta.cell(row=i, column=1, value=k).font = BODY_FONT
        meta.cell(row=i, column=2, value=v).font = BODY_FONT
    meta.column_dimensions["A"].width = 22
    meta.column_dimensions["B"].width = 70

    wb.save(out_path)


# --------------------------------------------------------------------------- Slack

SLACK_API = "https://slack.com/api/chat.postMessage"


def compute_summary(
    roster: list[str], rows: list[dict]
) -> tuple[list[tuple[str, int, int, int]], int, int, int]:
    """Return ([(name, total, draft, published), ...], grand_total, grand_draft, grand_pub)."""
    counts = {name: {"total": 0, "draft": 0, "published": 0} for name in roster}
    for r in rows:
        name = r["engineer"]
        if name not in counts:
            continue
        counts[name]["total"] += 1
        if r["status"] == "Draft":
            counts[name]["draft"] += 1
        elif r["status"] == "Published":
            counts[name]["published"] += 1
    # Sort by total desc, then name asc for stable output
    summary = sorted(
        [(n, c["total"], c["draft"], c["published"]) for n, c in counts.items()],
        key=lambda x: (-x[1], x[0]),
    )
    gt = sum(x[1] for x in summary)
    gd = sum(x[2] for x in summary)
    gp = sum(x[3] for x in summary)
    return summary, gt, gd, gp


def format_slack_blocks(
    month_label: str,
    summary: list[tuple[str, int, int, int]],
    grand_total: int,
    grand_draft: int,
    grand_pub: int,
    missing: list[str],
) -> list[dict]:
    header = {
        "type": "header",
        "text": {"type": "plain_text", "text": f"KB Articles \u2014 {month_label}"},
    }
    summary_line = {
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": (
                f"*{grand_total}* article(s) created across the team this month "
                f"(\u2022 {grand_pub} published \u2022 {grand_draft} draft)"
            ),
        },
    }

    # Fixed-width table via triple-backtick code block for clean Slack render
    name_w = max(len(n) for n, *_ in summary) if summary else 8
    name_w = max(name_w, len("Engineer"))
    lines = [
        f"{'Engineer':<{name_w}}  {'Total':>5}  {'Draft':>5}  {'Pub':>4}",
        f"{'-' * name_w}  {'-'*5}  {'-'*5}  {'-'*4}",
    ]
    for name, total, draft, pub in summary:
        lines.append(f"{name:<{name_w}}  {total:>5}  {draft:>5}  {pub:>4}")
    lines.append(f"{'-' * name_w}  {'-'*5}  {'-'*5}  {'-'*4}")
    lines.append(f"{'Total':<{name_w}}  {grand_total:>5}  {grand_draft:>5}  {grand_pub:>4}")
    table = "```\n" + "\n".join(lines) + "\n```"
    table_block = {"type": "section", "text": {"type": "mrkdwn", "text": table}}

    blocks: list[dict] = [header, summary_line, table_block]
    if missing:
        blocks.append(
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": (
                            ":warning: Could not resolve Pylon user ID for: "
                            + ", ".join(f"`{m}`" for m in missing)
                        ),
                    }
                ],
            }
        )
    blocks.append(
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"_Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}_",
                }
            ],
        }
    )
    return blocks


def post_to_slack(channel: str, blocks: list[dict], fallback_text: str) -> None:
    token = os.environ.get("SLACK_BOT_TOKEN")
    if not token:
        print("SLACK_BOT_TOKEN not set; skipping Slack post.", file=sys.stderr)
        return
    r = requests.post(
        SLACK_API,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
        },
        json={"channel": channel, "text": fallback_text, "blocks": blocks},
        timeout=30,
    )
    r.raise_for_status()
    body = r.json()
    if not body.get("ok"):
        raise RuntimeError(f"Slack API error: {body.get('error')} (full response: {body})")
    print(f"Posted summary to Slack channel {channel} (ts={body.get('ts')}).", file=sys.stderr)


# --------------------------------------------------------------------------- Main

def main() -> int:
    args = parse_args()
    year, month = resolve_month(args.month)
    roster = load_roster(args.roster)

    output_dir = Path(os.path.expanduser(args.output))
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"KB_Articles_{MONTH_NAMES[month]}_{year}.xlsx"

    token = get_token()
    session = make_session(token)

    print(f"Resolving Pylon user IDs for {len(roster)} engineers...", file=sys.stderr)
    name_to_id = build_user_map(session)
    target_ids: dict[str, str] = {}
    missing: list[str] = []
    for full in roster:
        uid = name_to_id.get(full.lower())
        if uid:
            target_ids[uid] = full
        else:
            missing.append(full)
    if missing:
        print(f"WARNING: could not resolve: {missing}", file=sys.stderr)

    lower, upper = month_bounds_utc(year, month)
    print(f"Fetching articles for {MONTH_NAMES[month]} {year}...", file=sys.stderr)
    rows = filter_rows(fetch_articles(session), target_ids, lower, upper)
    print(f"Filtered to {len(rows)} article(s).", file=sys.stderr)

    write_workbook(out_path, year, month, roster, rows, missing)
    print(str(out_path))

    # Optional Slack post
    if args.slack_channel and not args.no_slack:
        summary, gt, gd, gp = compute_summary(roster, rows)
        month_label = f"{MONTH_NAMES[month]} {year}"
        blocks = format_slack_blocks(month_label, summary, gt, gd, gp, missing)
        fallback = (
            f"KB Articles \u2014 {month_label}: {gt} total ({gp} published, {gd} draft)"
        )
        try:
            post_to_slack(args.slack_channel, blocks, fallback)
        except Exception as e:
            # Don't fail the whole run if Slack is down \u2014 the Excel is already written.
            print(f"Slack post failed: {e}", file=sys.stderr)
    elif args.no_slack:
        print("--no-slack flag set; skipping Slack post.", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
