# Pylon Monthly KB Report — Ubuntu deploy package

Two systemd services:

1. `pylon-monthly-report.timer` → fires `pylon-monthly-report.service` on the 1st of every month. Generates the Excel, posts a summary to Slack.
2. `pylon-slack-bot.service` *(optional)* → long-running Socket Mode listener. Lets users `@Support Bot` to generate on-demand reports for any month.

Both run as your user, with the app + data under `~/pylon-monthly-report/`.

## Quick start

```bash
# On the target VM, as the joon user:
scp pylon-monthly-report.tar.gz joon@vm:~
ssh joon@vm

tar xzf pylon-monthly-report.tar.gz -C "$HOME"
cd ~/pylon-monthly-report
sudo ./install.sh
$EDITOR ~/pylon-monthly-report/.env         # paste the four real values
sudo systemctl restart pylon-monthly-report.timer
sudo systemctl restart pylon-slack-bot.service      # only if you set SLACK_APP_TOKEN
```

`install.sh` auto-installs `python3-pip`, `requests`, `openpyxl`, and `slack_bolt`. It enables the bot service only if `SLACK_APP_TOKEN=xapp-...` is already set in the env file; otherwise it tells you to enable it manually after filling in the token.

## Package contents

| File | Installed to | Notes |
|---|---|---|
| `pylon_monthly_report.py` | `~/pylon-monthly-report/` | Monthly report generator. |
| `pylon_slack_bot.py` | `~/pylon-monthly-report/` | Socket Mode listener for on-demand reports. |
| `pylon-monthly-report.service` | `/etc/systemd/system/` | Runs the monthly script as `joon`. |
| `pylon-monthly-report.timer` | `/etc/systemd/system/` | Monthly trigger. |
| `pylon-slack-bot.service` | `/etc/systemd/system/` | Long-running bot (Restart=always). |
| `pylon-monthly-report.env.template` | copied to `~/pylon-monthly-report/.env` | Hidden dotfile, joon:joon, mode 600. |
| `install.sh` | — | Bootstrap; idempotent; requires sudo. |
| `README_monthly_report.md` | `~/pylon-monthly-report/` | Full reference incl. Slack app setup. |

## Slack app setup

See the *Slack setup* and *On-demand reports from Slack* sections of `README_monthly_report.md`. Short version: add `chat:write` + `app_mentions:read` bot scopes, enable Socket Mode, subscribe to `app_mention`, install to workspace, invite the bot to the channel.

## Security

Rotate your Pylon, Slack Bot, and Slack App tokens if any has ever been pasted into a chat, commit, or screenshot. Keep `~/pylon-monthly-report/.env` at mode 600 — `install.sh` sets this, don't loosen it.

## Mention grammar

```
@Support Bot report for January
@Support Bot Feb 2025
@Support Bot last month
@Support Bot 2026-04
@Support Bot help
```
