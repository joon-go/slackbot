#!/usr/bin/env bash
# install.sh — set up the Pylon monthly report as a SYSTEM systemd service,
# with the script and data living in the user's home directory.
#
# Run as root (sudo), from inside the extracted tarball:
#
#     tar xzf pylon-monthly-report.tar.gz -C "$HOME"
#     cd ~/pylon-monthly-report
#     sudo ./install.sh
#
# Idempotent: re-running upgrades files without disturbing .env or the timer.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root (sudo ./install.sh). System service units must be installed under /etc/systemd/system/." >&2
  exit 1
fi

# Determine which real user owns the app. Prefer $SUDO_USER; fall back to
# the owner of the install directory.
TARGET_USER="${SUDO_USER:-}"
if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
  TARGET_USER="$(stat -c '%U' "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" 2>/dev/null || echo)"
fi
if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
  echo "ERROR: could not determine the non-root user. Re-run via 'sudo ./install.sh'." >&2
  exit 1
fi

TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
if [[ -z "$TARGET_HOME" || ! -d "$TARGET_HOME" ]]; then
  echo "ERROR: could not resolve home directory for user '$TARGET_USER'." >&2
  exit 1
fi

APP_DIR="$TARGET_HOME/pylon-monthly-report"
ENV_FILE="$APP_DIR/.env"
UNIT_DIR="/etc/systemd/system"
SERVICE="pylon-monthly-report.service"
TIMER="pylon-monthly-report.timer"
BOT_SERVICE="pylon-slack-bot.service"

# Where THIS script was extracted to (must contain the payload).
SRC_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"

say()  { printf "\033[1;36m==>\033[0m %s\n" "$*"; }
warn() { printf "\033[1;33m!!\033[0m  %s\n" "$*" >&2; }

say "Installing for user '$TARGET_USER' (home: $TARGET_HOME)"

# 1. App directory ---------------------------------------------------------
if [[ "$SRC_DIR" != "$APP_DIR" ]]; then
  say "Copying payload to $APP_DIR"
  mkdir -p "$APP_DIR"
  install -m 644 "$SRC_DIR/pylon_monthly_report.py"          "$APP_DIR/"
  install -m 644 "$SRC_DIR/pylon_slack_bot.py"               "$APP_DIR/"
  install -m 644 "$SRC_DIR/README_monthly_report.md"         "$APP_DIR/"
  install -m 644 "$SRC_DIR/pylon-monthly-report.env.template" "$APP_DIR/"
else
  say "Using payload in place at $APP_DIR"
fi
mkdir -p "$APP_DIR/reports" "$APP_DIR/logs"
chown -R "$TARGET_USER:$TARGET_USER" "$APP_DIR"

# 2. Python dependencies ---------------------------------------------------
# Ensure python3 itself is present.
if ! command -v python3 >/dev/null; then
  say "python3 not found; installing via apt"
  DEBIAN_FRONTEND=noninteractive apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3
fi

# Ensure pip is present. Ubuntu's minimal images ship python3 without pip,
# which is the most common install failure. Fix it via apt.
if ! python3 -m pip --version >/dev/null 2>&1; then
  say "python3 -m pip not available; installing python3-pip via apt"
  DEBIAN_FRONTEND=noninteractive apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip
fi

# venv is sometimes a separate package on Ubuntu; it's not strictly needed
# for --user installs, but nice to have for troubleshooting.
if ! python3 -c "import venv" 2>/dev/null; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv 2>/dev/null || true
fi

say "Installing Python dependencies (requests, openpyxl) for $TARGET_USER"
PIP_FLAGS=(--user --upgrade)
if python3 -c "import sys, sysconfig, os; p = sysconfig.get_paths()['stdlib']; sys.exit(0 if os.path.exists(p + '/EXTERNALLY-MANAGED') else 1)"; then
  PIP_FLAGS+=(--break-system-packages)
  say "Detected PEP 668 managed Python; using --break-system-packages"
fi
# --user installs into the target user's ~/.local, not root's.
sudo -u "$TARGET_USER" python3 -m pip install "${PIP_FLAGS[@]}" requests openpyxl slack_bolt

# 3. Patch hardcoded "joon" paths in the service unit if the target differs -
say "Installing systemd unit files to $UNIT_DIR"
if [[ "$TARGET_USER" != "joon" ]]; then
  warn "Service unit ships hardcoded to user 'joon'; rewriting for '$TARGET_USER'."
  sed -e "s|^User=joon$|User=$TARGET_USER|" \
      -e "s|^Group=joon$|Group=$TARGET_USER|" \
      -e "s|/home/joon/pylon-monthly-report|$APP_DIR|g" \
      "$SRC_DIR/$SERVICE" > "$UNIT_DIR/$SERVICE"
  chmod 644 "$UNIT_DIR/$SERVICE"
else
  install -m 644 "$SRC_DIR/$SERVICE" "$UNIT_DIR/$SERVICE"
fi
install -m 644 "$SRC_DIR/$TIMER" "$UNIT_DIR/$TIMER"

# Slack bot service (Socket Mode listener, long-running)
if [[ -f "$SRC_DIR/$BOT_SERVICE" ]]; then
  if [[ "$TARGET_USER" != "joon" ]]; then
    sed -e "s|^User=joon$|User=$TARGET_USER|" \
        -e "s|^Group=joon$|Group=$TARGET_USER|" \
        -e "s|/home/joon/pylon-monthly-report|$APP_DIR|g" \
        "$SRC_DIR/$BOT_SERVICE" > "$UNIT_DIR/$BOT_SERVICE"
    chmod 644 "$UNIT_DIR/$BOT_SERVICE"
  else
    install -m 644 "$SRC_DIR/$BOT_SERVICE" "$UNIT_DIR/$BOT_SERVICE"
  fi
fi

systemctl daemon-reload

# 4. Env file --------------------------------------------------------------
if [[ ! -f "$ENV_FILE" ]]; then
  say "Creating $ENV_FILE from template"
  install -o "$TARGET_USER" -g "$TARGET_USER" -m 600 \
    "$SRC_DIR/pylon-monthly-report.env.template" "$ENV_FILE"
  cat <<MSG

  ----------------------------------------------------------------
  $ENV_FILE was created from the template. It still contains
  placeholder values. Edit it now (as the $TARGET_USER user, not root):

      su - $TARGET_USER -c '\$EDITOR $ENV_FILE'
      # or from a $TARGET_USER shell:  nano $ENV_FILE

  Set:
      PYLON_TOKEN=...           (your Pylon API token)
      SLACK_BOT_TOKEN=xoxb-...  (your Slack bot token)
      SLACK_CHANNEL=#channel    (or a channel ID like CXXXXXXXXXX)

  Hidden dotfile (.env) owned $TARGET_USER:$TARGET_USER mode 600 \u2014
  readable only by $TARGET_USER.
  ----------------------------------------------------------------

MSG
else
  say "$ENV_FILE already present, leaving it alone"
  chown "$TARGET_USER:$TARGET_USER" "$ENV_FILE" || true
  chmod 600 "$ENV_FILE" || true
fi

# 5. Timer + bot service ---------------------------------------------------
say "Enabling and starting $TIMER"
systemctl enable --now "$TIMER"

if [[ -f "$UNIT_DIR/$BOT_SERVICE" ]]; then
  # Only enable the bot if the env file has a Slack App Token; otherwise it
  # would crash in a restart loop. Grep without exposing the value.
  if [[ -f "$ENV_FILE" ]] && grep -q "^SLACK_APP_TOKEN=xapp-" "$ENV_FILE"; then
    say "Enabling and starting $BOT_SERVICE"
    systemctl enable --now "$BOT_SERVICE"
  else
    warn "SLACK_APP_TOKEN not set in $ENV_FILE; skipping $BOT_SERVICE start."
    warn "After adding SLACK_APP_TOKEN=xapp-..., run: sudo systemctl enable --now $BOT_SERVICE"
  fi
fi

# 6. Summary ---------------------------------------------------------------
echo
say "Done. Next scheduled run:"
systemctl list-timers "$TIMER" --no-pager | sed 's/^/    /'
echo
cat <<MSG
Useful commands:

    # Force a run right now (picks up whatever's in $ENV_FILE)
    sudo systemctl start $SERVICE

    # Tail the run log
    journalctl -u $SERVICE -f

    # Show recent runs
    systemctl list-timers $TIMER
    journalctl -u $SERVICE -n 200 --no-pager

    # Disable scheduled runs
    sudo systemctl disable --now $TIMER
MSG
