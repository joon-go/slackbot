#!/usr/bin/env python3
"""
Pylon KB authoring report — on-demand Slack bot.

Long-running listener using Slack Socket Mode. When the bot is @-mentioned
in a channel, it parses the message for a month, runs the same pipeline as
pylon_monthly_report.py, and posts a summary table in the thread.

Examples of mentions the bot accepts:

    @Support Bot give me report for January
    @Support Bot report for Feb 2025
    @Support Bot last month
    @Support Bot this month
    @Support Bot 2026-04

Requirements (pip install slack_bolt requests openpyxl):
    slack_bolt>=1.18

Env vars required:
    PYLON_TOKEN         Pylon API bearer token (or PYLON_API_KEY)
    SLACK_BOT_TOKEN     xoxb-... Bot User OAuth token
    SLACK_APP_TOKEN     xapp-... App-Level token with connections:write
                        (generate in Slack app admin \u2192 Basic Information
                        \u2192 App-Level Tokens)

Optional:
    PYLON_ROSTER_PATH   JSON file overriding the default roster of engineers.
"""

from __future__ import annotations

import calendar
import json
import logging
import os
import re
import sys
import traceback
from datetime import date, datetime, timezone
from typing import Iterable

import requests

try:
    from slack_bolt import App
    from slack_bolt.adapter.socket_mode import SocketModeHandler
except ImportError:
    sys.exit(
        "ERROR: slack_bolt not installed. "
        "Run: pip install --user slack_bolt requests"
    )

# Re-use the battle-tested logic from pylon_monthly_report.py.
# This file is expected to sit next to pylon_monthly_report.py.
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import pylon_monthly_report as report  # noqa: E402


# --------------------------------------------------------------------------- Config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("pylon-slack-bot")


def _env(*names: str) -> str | None:
    for n in names:
        v = os.environ.get(n)
        if v:
            return v
    return None


PYLON_TOKEN = _env("PYLON_API_KEY", "PYLON_TOKEN", "pylon_token")
SLACK_BOT_TOKEN = _env("SLACK_BOT_TOKEN")
SLACK_APP_TOKEN = _env("SLACK_APP_TOKEN")
ROSTER_PATH = _env("PYLON_ROSTER_PATH")

_missing = [
    n for n, v in (
        ("PYLON_TOKEN / PYLON_API_KEY", PYLON_TOKEN),
        ("SLACK_BOT_TOKEN", SLACK_BOT_TOKEN),
        ("SLACK_APP_TOKEN", SLACK_APP_TOKEN),
    ) if not v
]
if _missing:
    sys.exit(f"ERROR: missing env var(s): {', '.join(_missing)}")


# --------------------------------------------------------------------------- Month parsing

MONTH_NUMBERS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

MONTH_NAME_PATTERN = "|".join(sorted(MONTH_NUMBERS.keys(), key=len, reverse=True))
MONTH_REGEX = re.compile(
    rf"\b(?P<month>{MONTH_NAME_PATTERN})\b(?:\s+(?P<year>\d{{4}}))?",
    re.IGNORECASE,
)
YYYYMM_REGEX = re.compile(r"\b(?P<year>\d{4})[-/](?P<month>0?[1-9]|1[0-2])\b")


def parse_month(text: str, today: date | None = None) -> tuple[int, int] | None:
    """Return (year, month) parsed from free-form text, or None."""
    today = today or date.today()
    t = text.lower()

    # Shortcuts
    if "last month" in t or "previous month" in t:
        return report.previous_full_month(today)
    if "this month" in t or "current month" in t:
        return (today.year, today.month)

    m = YYYYMM_REGEX.search(text)
    if m:
        return int(m.group("year")), int(m.group("month"))

    m = MONTH_REGEX.search(text)
    if m:
        month = MONTH_NUMBERS[m.group("month").lower()]
        year = int(m.group("year")) if m.group("year") else today.year
        # If user said "January" and we're in March, assume current year
        # (they likely mean January of this year). If they said a future
        # month relative to today, assume last year.
        if not m.group("year") and month > today.month:
            year -= 1
        return year, month

    return None


# --------------------------------------------------------------------------- Pylon fetch

_SESSION: requests.Session | None = None


def pylon_session() -> requests.Session:
    global _SESSION
    if _SESSION is None:
        _SESSION = report.make_session(PYLON_TOKEN)
    return _SESSION


def load_roster() -> list[str]:
    if ROSTER_PATH and os.path.exists(ROSTER_PATH):
        with open(ROSTER_PATH) as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("engineers"), list):
            return data["engineers"]
    return report.DEFAULT_ROSTER


def build_summary(year: int, month: int) -> str:
    session = pylon_session()
    roster = load_roster()

    name_to_id = report.build_user_map(session)
    target_ids: dict[str, str] = {}
    missing: list[str] = []
    for full in roster:
        uid = name_to_id.get(full.lower())
        if uid:
            target_ids[uid] = full
        else:
            missing.append(full)

    lower, upper = report.month_bounds_utc(year, month)
    rows = report.filter_rows(report.fetch_articles(session), target_ids, lower, upper)
    summary, gt, gd, gp = report.compute_summary(roster, rows)
    month_label = f"{report.MONTH_NAMES[month]} {year}"

    # Monospaced table matching the monthly report look-and-feel
    name_w = max(len(n) for n, *_ in summary) if summary else 8
    name_w = max(name_w, len("Engineer"))
    lines = [
        f"{'Engineer':<{name_w}}  {'Total':>5}  {'Draft':>5}  {'Pub':>4}",
        f"{'-' * name_w}  {'-'*5}  {'-'*5}  {'-'*4}",
    ]
    for name, total, draft, pub in summary:
        lines.append(f"{name:<{name_w}}  {total:>5}  {draft:>5}  {pub:>4}")
    lines.append(f"{'-' * name_w}  {'-'*5}  {'-'*5}  {'-'*4}")
    lines.append(f"{'Total':<{name_w}}  {gt:>5}  {gd:>5}  {gp:>4}")
    table = "```\n" + "\n".join(lines) + "\n```"

    parts = [
        f"*KB Articles — {month_label}*",
        f"*{gt}* article(s) created (• {gp} published • {gd} draft)",
        table,
    ]
    if missing:
        parts.append(
            ":warning: Could not resolve Pylon user ID for: "
            + ", ".join(f"`{m}`" for m in missing)
        )
    return "\n".join(parts)


# --------------------------------------------------------------------------- Slack handler

HELP_TEXT = (
    "Hi! I post KB authoring reports on demand. Try:\n"
    "• `@me report for January`\n"
    "• `@me give me the Feb 2025 report`\n"
    "• `@me last month`\n"
    "• `@me this month`\n"
    "• `@me 2026-04`\n"
    "I default to the current calendar year if you don't specify one."
)


app = App(token=SLACK_BOT_TOKEN)


@app.event("app_mention")
def handle_mention(event, say, logger):
    raw_text = event.get("text", "") or ""
    # Strip the leading @mention token(s) before parsing.
    text = re.sub(r"<@[A-Z0-9]+>", "", raw_text).strip()
    channel = event.get("channel")
    thread_ts = event.get("thread_ts") or event.get("ts")

    logger.info("received mention: %r (channel=%s)", text, channel)

    if not text or re.fullmatch(r"(?i)help|\?", text):
        say(text=HELP_TEXT, channel=channel, thread_ts=thread_ts)
        return

    parsed = parse_month(text)
    if not parsed:
        say(
            text=f"I couldn't find a month in that. {HELP_TEXT}",
            channel=channel,
            thread_ts=thread_ts,
        )
        return

    year, month = parsed
    if not (2000 <= year <= 2100) or not (1 <= month <= 12):
        say(
            text=f":warning: `{year}-{month:02d}` is out of range.",
            channel=channel,
            thread_ts=thread_ts,
        )
        return

    say(
        text=f"Generating KB report for *{report.MONTH_NAMES[month]} {year}*…",
        channel=channel,
        thread_ts=thread_ts,
    )

    try:
        body = build_summary(year, month)
    except Exception:
        logger.exception("report generation failed")
        say(
            text=(
                ":x: Report generation failed. Check the bot logs "
                "(`journalctl -u pylon-slack-bot.service -n 200`)."
            ),
            channel=channel,
            thread_ts=thread_ts,
        )
        return

    say(text=body, channel=channel, thread_ts=thread_ts)


@app.event("message")
def _ignore_non_mentions(event, logger):
    # Slack delivers every message; we only care about app_mention events.
    # This handler just silences the "unhandled event" warnings from bolt.
    return


# --------------------------------------------------------------------------- Main

def main() -> None:
    log.info("Starting Pylon KB Slack bot (Socket Mode)")
    SocketModeHandler(app, SLACK_APP_TOKEN).start()


if __name__ == "__main__":
    main()
