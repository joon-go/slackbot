# Pylon Monthly KB Authoring Report

Generates an Excel report each month showing how many KB articles each engineer authored, broken down by draft vs. published.

## Files

- `pylon_monthly_report.py` — the script. One file, two dependencies (`requests`, `openpyxl`).
- `com.coderabbit.pylon-monthly-report.plist` — launchd job that runs the script on the 1st of every month.
- `roster.json` (optional) — override the default 10-engineer list without editing the script.

## One-time setup

```bash
# 1. Pick a home for the script and reports.
REPORT_DIR="$HOME/Documents/pylon-reports"
mkdir -p "$REPORT_DIR/reports" "$REPORT_DIR/logs"
cp pylon_monthly_report.py "$REPORT_DIR/"

# 2. Install dependencies.
python3 -m pip install --user requests openpyxl

# 3. Verify by running once for last month.
export PYLON_TOKEN='your_pylon_token'
python3 "$REPORT_DIR/pylon_monthly_report.py" --output "$REPORT_DIR/reports"
# → writes KB_Articles_<Month>_<Year>.xlsx into $REPORT_DIR/reports
```

## Ad-hoc runs

```bash
# Previous full month (default)
python3 pylon_monthly_report.py

# Specific month
python3 pylon_monthly_report.py --month 2026-04

# Different output dir
python3 pylon_monthly_report.py --output ~/Desktop

# Custom roster
python3 pylon_monthly_report.py --roster roster.json

# Post the summary to Slack
export SLACK_BOT_TOKEN='xoxb-...'
python3 pylon_monthly_report.py --slack-channel '#kb-reports'

# Skip Slack even if SLACK_BOT_TOKEN is set
python3 pylon_monthly_report.py --no-slack
```

`roster.json` format:

```json
{ "engineers": ["Jane Doe", "John Smith"] }
```

The Pylon token can be set as any of `PYLON_API_KEY`, `PYLON_TOKEN`, or `pylon_token`. The Slack channel can be passed with `--slack-channel` or via the `SLACK_CHANNEL` env var.

## Slack setup

The script posts via Slack's `chat.postMessage` API. One-time app setup:

1. Go to https://api.slack.com/apps → *Create New App* → *From scratch*. Name it something like "KB Authoring Report". Pick your workspace.
2. *OAuth & Permissions* → *Bot Token Scopes* → add `chat:write`.
3. *Install App* → *Install to Workspace* → approve. Copy the *Bot User OAuth Token* that starts with `xoxb-`.
4. In Slack, invite the bot to the channel you want to post in: `/invite @your-bot-name`.
5. Export the token locally and test:

    ```bash
    export SLACK_BOT_TOKEN='xoxb-your-token'
    python3 pylon_monthly_report.py --slack-channel '#kb-reports'
    ```

Channel formats that work: `#channel-name`, `channel-name`, or the channel ID `CXXXXXXXXXX`. IDs are more robust because channel names can change.

If the Slack post fails for any reason (bad token, bot not in channel, Slack outage), the script still writes the Excel file and exits 0 — it logs the Slack error to stderr but doesn't fail the whole run.

## On-demand reports from Slack

Alongside the monthly timer, there's an optional Slack bot (`pylon_slack_bot.py`) that listens for @-mentions and generates a report for any month you ask about. It runs as a second long-lived systemd service (`pylon-slack-bot.service`) and talks to Slack via **Socket Mode** — no public IP or reverse proxy on your VM.

### What the bot does

When someone @-mentions the bot in a channel it's been invited to, it parses the message for a month, fetches the articles, and posts the same monospaced summary table as the monthly report — as a threaded reply to the mention.

Examples it accepts:

```
@Support Bot give me report for January
@Support Bot report for Feb 2025
@Support Bot last month
@Support Bot this month
@Support Bot 2026-04
@Support Bot help
```

Default year is the current calendar year. If you say just `January` and it's already April, it assumes January of this year. If you say `September` (a future month), it assumes last year's September.

### Slack app setup for on-demand

Do this once in your Slack app admin, in addition to the scopes you already added for the monthly post:

1. Left sidebar → **Socket Mode** → toggle *Enable Socket Mode*. When prompted, create an **App-Level Token** with scope `connections:write`. Copy it — starts with `xapp-`.
2. **OAuth & Permissions** → Bot Token Scopes → add `app_mentions:read`.
3. **Event Subscriptions** → toggle on. Under *Subscribe to bot events*, add `app_mention`.
4. **Install App** → *Reinstall to Workspace*. Copy the refreshed `xoxb-` token.
5. In Slack, `/invite @your-bot-name` to each channel where you want people to mention it.

Then on the VM, add the App-Level token to the env file:

```
SLACK_APP_TOKEN=xapp-your-app-token
```

`install.sh` installs the `pylon-slack-bot.service` unit automatically and starts it if `SLACK_APP_TOKEN` is already set in the env file. If you add the token after the first install, enable the bot service explicitly:

```bash
sudo systemctl enable --now pylon-slack-bot.service
journalctl -u pylon-slack-bot.service -n 50 --no-pager
```

You should see `Starting Pylon KB Slack bot (Socket Mode)` followed by `slack_bolt` connection logs.

### Managing the bot

```bash
systemctl status pylon-slack-bot.service             # running?
journalctl -u pylon-slack-bot.service -f             # tail live
sudo systemctl restart pylon-slack-bot.service       # reload tokens / code
sudo systemctl disable --now pylon-slack-bot.service # turn off on-demand
```

The bot auto-restarts on crash or WebSocket disconnect (`Restart=always`). The monthly timer is independent — disabling the bot doesn't affect the monthly post.

## Schedule it (Ubuntu, system systemd timer + home-dir app)

System service (installed under `/etc/systemd/system/`) that runs as the `joon` user, with the script and data under `/home/joon/pylon-monthly-report/`. `install.sh` wires it up.

| File | Installed at | Purpose |
|---|---|---|
| `pylon-monthly-report.service` | `/etc/systemd/system/` | Runs the script as `joon`. |
| `pylon-monthly-report.timer`   | `/etc/systemd/system/` | Fires the service on the 1st of every month at 07:00 local. |
| `.env`                         | `/home/joon/pylon-monthly-report/.env` | Hidden dotfile. Pylon token, Slack token, channel. `joon:joon` mode 600. |

### One-time install

```bash
# From the joon user's shell on the VM:
tar xzf pylon-monthly-report.tar.gz -C "$HOME"
cd ~/pylon-monthly-report
sudo ./install.sh
$EDITOR ~/pylon-monthly-report/.env        # paste the three real values
sudo systemctl restart pylon-monthly-report.timer
```

No `loginctl enable-linger` needed — system units run whether or not you're logged in.

### Verify

```bash
# Is the timer armed and when does it fire next?
systemctl list-timers pylon-monthly-report.timer

# Status of the last run (if any).
systemctl status pylon-monthly-report.service

# Full log output from the most recent run.
journalctl -u pylon-monthly-report.service -n 200 --no-pager
```

`list-timers` should show a `NEXT` column of the 1st of next month at 07:00.

### Force a run right now

```bash
sudo systemctl start pylon-monthly-report.service
journalctl -u pylon-monthly-report.service -f
```

The Excel lands in `~/pylon-monthly-report/reports/KB_Articles_<Month>_<Year>.xlsx` and the Slack summary is posted (if configured). To override the target month for a one-off run without touching the timer:

```bash
source ~/pylon-monthly-report/.env
python3 ~/pylon-monthly-report/pylon_monthly_report.py \
    --month 2026-03 \
    --output ~/pylon-monthly-report/reports \
    --slack-channel "$SLACK_CHANNEL"
```

### Uninstall

```bash
sudo systemctl disable --now pylon-monthly-report.timer
sudo rm /etc/systemd/system/pylon-monthly-report.{service,timer}
sudo systemctl daemon-reload
# (optional) rm -rf ~/pylon-monthly-report
```

### Hardening notes

The service runs as `joon`, not root, and inherits standard user privileges. Unit hardening applied: `NoNewPrivileges`, `ProtectSystem=strict` (read-only `/usr` `/boot` `/efi`), `PrivateTmp`, `PrivateDevices`, `ProtectKernelTunables`, `ProtectKernelModules`, `ProtectControlGroups`, `RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX`, `RestrictNamespaces`, `LockPersonality`, `MemoryDenyWriteExecute`, `SystemCallArchitectures=native`.

`ProtectHome` is intentionally **off** because the app lives in `/home/joon`. The tradeoff: a bug or injection in the script has access to other files under `/home/joon`. If that's a concern, move the app to `/opt/pylon-reports/` with a dedicated `pylon` system user and turn `ProtectHome=true` back on. `ReadWritePaths` is scoped to the `reports/` and `logs/` subdirs, so with `ProtectSystem=strict` the script can't write anywhere outside its own data dirs.

## Schedule it (macOS launchd)

```bash
# 1. Edit the plist. Four placeholders to replace:
#    REPORT_DIR                        → absolute path to your report dir
#    REPLACE_WITH_SLACK_CHANNEL        → e.g. #kb-reports or CXXXXXXXXXX
#    REPLACE_WITH_YOUR_PYLON_TOKEN     → your Pylon API token
#    REPLACE_WITH_YOUR_SLACK_BOT_TOKEN → your xoxb-... token
#    Use absolute paths — launchd does not expand $HOME.
sed -i '' "s|REPORT_DIR|$REPORT_DIR|g" com.coderabbit.pylon-monthly-report.plist
# Then open the plist in a text editor and paste the three REPLACE_WITH_* values.

# 2. Install.
cp com.coderabbit.pylon-monthly-report.plist "$HOME/Library/LaunchAgents/"
chmod 600 "$HOME/Library/LaunchAgents/com.coderabbit.pylon-monthly-report.plist"
launchctl load "$HOME/Library/LaunchAgents/com.coderabbit.pylon-monthly-report.plist"

# 3. Verify it's scheduled.
launchctl list | grep pylon-monthly-report
```

The job fires at 07:00 local time on the 1st of each month. The script with no `--month` arg defaults to the previous full calendar month, so April's report is generated on May 1.

To force a run right now:

```bash
launchctl start com.coderabbit.pylon-monthly-report
tail -n 50 "$REPORT_DIR/logs/pylon-report.err.log"
```

To uninstall:

```bash
launchctl unload "$HOME/Library/LaunchAgents/com.coderabbit.pylon-monthly-report.plist"
rm "$HOME/Library/LaunchAgents/com.coderabbit.pylon-monthly-report.plist"
```

## Schedule it (cron alternative)

If you prefer cron, add this to `crontab -e`:

```
0 7 1 * * cd "$HOME/Documents/pylon-reports" && PYLON_TOKEN='your_token' /usr/bin/python3 pylon_monthly_report.py --output reports >> logs/pylon-report.out.log 2>> logs/pylon-report.err.log
```

cron runs in a minimal shell, so use absolute paths for python3 and the report dir. launchd is the more Mac-native option.

## Output format

Each run writes `KB_Articles_<Month>_<Year>.xlsx` with three sheets:

| Sheet     | Contents |
|-----------|---|
| Summary   | One row per engineer. Columns: Engineer, # Articles, # Draft, # Published. Counts are live COUNTIFS formulas pointing at the Details sheet, so edits flow through. |
| Details   | One row per article. Columns: Engineer, Topic / Title, Status, Created Date, Article ID, URL. Dropdowns on Engineer and Status. |
| Run info  | Month label, timestamp of the run, count of articles pulled, and any engineer names that couldn't be resolved to a Pylon user ID. |

## Security notes

- Keep the plist chmod 600 — it contains your Pylon token in plaintext. Anyone who can read the file can read the token.
- If you ever paste the token into chat (as happened once during this setup), rotate it in Pylon afterward.
- The token needs permissions to read `/users` and `/knowledge-bases/*/articles`. Read-only API keys are sufficient.

## Troubleshooting

- **"could not resolve: [...]"** in stderr — the script couldn't match one of the roster names to a Pylon user. Check spelling against the exact `name` field on the Pylon user record, or switch to `--roster` with corrected names.
- **Empty report** — either no one in the roster authored anything that month (plausible), or the Pylon token doesn't have permission to see the relevant KB. Run without redirection to stderr and check the `Fetching articles...` / `Filtered to N article(s).` log lines.
- **`ModuleNotFoundError: openpyxl`** — the python3 launchd is using isn't the one you pip-installed into. Either install with `sudo python3 -m pip install requests openpyxl`, or point the plist's ProgramArguments at the exact python3 binary where those packages live (e.g., `/opt/homebrew/bin/python3`).
